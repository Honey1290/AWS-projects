package com.nextwork.app;

public class App {
    public static void main(String[] args) {
        System.out.println("NextWork Web App Initialized!");
    }
}
