# Step4 SSH Connection

Detailed explanation of this step is in your project notes.