# Step1 IAM User

Detailed explanation of this step is in your project notes.