# Step7 Connect VSCode to EC2

Detailed explanation of this step is in your project notes.