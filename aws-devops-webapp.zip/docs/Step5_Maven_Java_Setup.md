# Step5 Maven Java Setup

Detailed explanation of this step is in your project notes.