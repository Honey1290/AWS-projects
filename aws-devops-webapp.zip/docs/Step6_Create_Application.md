# Step6 Create Application

Detailed explanation of this step is in your project notes.