# Step3 VSCode Setup

Detailed explanation of this step is in your project notes.