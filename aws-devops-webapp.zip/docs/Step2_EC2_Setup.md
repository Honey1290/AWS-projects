# Step2 EC2 Setup

Detailed explanation of this step is in your project notes.