# ☁️ AWS Web App Deployment using VS Code & EC2

## 📘 Overview
This project demonstrates how to set up and deploy a simple **Java web application** on **AWS EC2** and configure it through **Visual Studio Code** using **SSH**.  
It’s the first stage of my DevOps learning journey — focusing on cloud, automation, and CI/CD foundations.

---

## 🧰 Tools & Technologies
- **AWS EC2** — Virtual cloud server
- **AWS IAM** — Secure user management
- **VS Code Remote SSH** — Remote configuration
- **Java & Apache Maven** — Web app creation
- **Linux CLI** — Server setup
- **.pem key** — Authentication for SSH access

---

## 🧱 Project Steps
| Step | Description | File |
|------|--------------|------|
| 1 | Create IAM User for secure access | [Step1_IAM_User.md](docs/Step1_IAM_User.md) |
| 2 | Launch EC2 Instance & Key Pair | [Step2_EC2_Setup.md](docs/Step2_EC2_Setup.md) |
| 3 | Install & Configure VS Code | [Step3_VSCode_Setup.md](docs/Step3_VSCode_Setup.md) |
| 4 | Connect EC2 with SSH | [Step4_SSH_Connection.md](docs/Step4_SSH_Connection.md) |
| 5 | Install Maven & Java | [Step5_Maven_Java_Setup.md](docs/Step5_Maven_Java_Setup.md) |
| 6 | Generate Web Application | [Step6_Create_Application.md](docs/Step6_Create_Application.md) |
| 7 | Connect VS Code to EC2 & Edit Files | [Step7_Connect_VSCode_to_EC2.md](docs/Step7_Connect_VSCode_to_EC2.md) |

---

## 🌐 Application Preview
Inside the EC2 instance, the Java web app structure is generated using Maven:
```
src/main/webapp/index.jsp
```
Example `index.jsp` content:
```html
<html>
  <body>
    <h2>Hello, Sanidhya Negi!</h2>
    <p>This is my NextWork web application running on AWS EC2.</p>
  </body>
</html>
```

---

## 💡 Learning Outcomes
- Learned to securely manage cloud access with IAM.
- Deployed and managed an EC2 instance via SSH.
- Configured VS Code for remote development.
- Installed and verified Java & Maven.
- Built a Java web app using Maven archetypes.

---

## 👨‍💻 Author
**Sanidhya Negi**  
📍 Dehradun, India  
📧 sanidhyanegi061@gmail.com  
🎓 B.Tech (CSE), DIT University  
⚽ Loves football | ☁️ Cloud enthusiast
